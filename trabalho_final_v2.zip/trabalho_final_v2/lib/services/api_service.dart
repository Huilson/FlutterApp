import 'package:retrofit/retrofit.dart';
import 'package:dio/dio.dart';
import '../my_game_page.dart';

part 'api_service.g.dart';

class Apis{
  static const String player = '/users';
}

@RestApi(baseUrl:"https://jsonplaceholder.typicode.com")
abstract class ApiClient{
  factory ApiClient(Dio dio, {String baseUrl}) = _ApiClient;

  @GET(Apis.player)
  Future<List<Player>> getPlayers();
}