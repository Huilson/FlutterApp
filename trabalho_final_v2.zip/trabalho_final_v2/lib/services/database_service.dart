import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final _fire = FirebaseFirestore.instance;

  readO() async {
    try {
      final data = await _fire.collection("score").get();
      final oScore = data.docs[0];
      print(oScore["O"]);
      return oScore["O"];
    } catch (e) {
      print(e);
      log(e.toString());
    }
  }

  readX() async {
    try {
      final data = await _fire.collection("score").get();
      final xScore = data.docs[0];
      print(xScore["X"]);
      return xScore["X"];
    } catch (e) {
      print(e);
      log(e.toString());
    }
  }

  update(x, o) async {
    try {
      await _fire.collection("score").doc("mk").update({"X": x, "O": o});
    } catch (e) {
      log(e.toString());
      print(e.toString());
    }
  }

  saveBattle(playerOne, playerTwo, winner) async{
    var champion;
    if(winner == "X"){
      champion = playerOne;
    }else if(winner == "O"){
      champion = playerTwo;
    }
    try {
      await _fire.collection("battle_history").add({
        "player_x" : playerOne,
        "player_o" : playerTwo,
        "winner" : champion,
      });
    } catch (e) {
      log(e.toString());
      print(e.toString());
    }
  }
}
