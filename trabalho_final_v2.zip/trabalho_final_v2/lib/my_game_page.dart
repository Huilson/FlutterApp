import 'dart:async';

import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:trabalho_final_v2/services/api_service.dart';
import 'package:trabalho_final_v2/services/database_service.dart';

class MyGame extends StatefulWidget {
  const MyGame({super.key});

  @override
  State<MyGame> createState() => _MyGameState();
}


class _MyGameState extends State<MyGame> {
  final _dbService = DatabaseService();

  final AssetsAudioPlayer _assetsAudioPlayer = AssetsAudioPlayer();
  final List<StreamSubscription> _subscriptions = [];
  final audios = <Audio>[
    Audio('assets/audios/MortalKombat.mp3',
        //playSpeed: 2.0,
        metas: Metas(
          id: 'MK',
          title: 'Techno Syndrome (Mortal Kombat)',
          artist: 'The Immortals',
          album: 'Mortal Kombat: The Album',
          image: const MetasImage.network(
              'https://upload.wikimedia.org/wikipedia/pt/0/0f/Mortal_kombat_logo.png'),
        ))
  ];

  List game = [
    ['', '', ''],
    ['', '', ''],
    ['', '', ''],
  ];

  String currentPlayer = 'X';
  String helpText = 'Round one fight!';
  bool startFight = false;

  int moves = 0;
  int xScore = 0;
  int oScore = 0;
  List<String> playersApi = [];
  List<DropdownMenuItem<String>> dropdownItems = [];

  var playerOne;
  var playerTwo;

  @override
  Widget build(BuildContext context) {
    return new FutureBuilder(
        future: loadPlayers(),
        initialData: "Loading...",
        builder: (BuildContext context, AsyncSnapshot<String> text) {
          return Scaffold(
            body: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AbsorbPointer(
                  absorbing: !startFight,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Text(
                              "Mortal Kombat",
                              style: TextStyle(
                                  fontSize: 50,
                                  color: Theme.of(context).colorScheme.primary,
                                  fontStyle: FontStyle.italic),
                            ),
                          ),
                        ],
                      ),
                      Center(
                        //mainAxisAlignment: MainAxisAlignment.center,
                          child: //[
                          Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Table(
                                border: TableBorder.all(color: Theme.of(context).colorScheme.tertiary),
                                defaultColumnWidth: const FixedColumnWidth(
                                    150.0),
                                defaultVerticalAlignment:
                                TableCellVerticalAlignment.middle,
                                children: [
                                  const TableRow(
                                      decoration: BoxDecoration(
                                        color: Colors.blueAccent,
                                      ),
                                      children: [
                                        TableCell(
                                          verticalAlignment:
                                          TableCellVerticalAlignment.middle,
                                          child: Padding(
                                              padding: EdgeInsets.all(8.0),
                                              child: Text('Player X')),
                                        ),
                                        TableCell(
                                          verticalAlignment:
                                          TableCellVerticalAlignment.middle,
                                          child: Padding(
                                              padding: EdgeInsets.all(8.0),
                                              child: Text('Player O')),
                                        ),
                                      ]),
                                  TableRow(
                                      decoration: const BoxDecoration(
                                        color: Colors.blueGrey,
                                      ),
                                      children: [
                                        Center(
                                          child: Padding(
                                              padding: const EdgeInsets.all(
                                                  8.0),
                                              child: Text('$xScore')),
                                        ),
                                        Center(
                                          child: Padding(
                                              padding: const EdgeInsets.all(
                                                  8.0),
                                              child: Text('$oScore')),
                                        ),
                                      ]),
                                  TableRow(
                                      decoration: const BoxDecoration(
                                          color: Colors.grey
                                      ),
                                      children: [
                                        Center(
                                          child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child:
                                              DropdownButton(
                                                hint: Text("Player 1"),
                                                isExpanded: true,
                                                value: playerOne,
                                                items: playersApi.map((e){
                                                  return DropdownMenuItem(
                                                      value: e,
                                                      child: Text(e));
                                                }).toList(),
                                                onChanged: (value) {
                                                  playerOne = value;
                                                  setState(() {});
                                                },
                                              ),
                                          ),
                                        ),
                                        Center(
                                          child: Padding(
                                            padding: const EdgeInsets.all(2.0),
                                            child:
                                            DropdownButton(
                                              hint: Text("Player 2"),
                                              isExpanded: true,
                                              value: playerTwo,
                                              items: playersApi.map((e){
                                                return DropdownMenuItem(
                                                    value: e,
                                                    child: Text(e));
                                              }).toList(),
                                              onChanged: (value) {
                                                playerTwo = value;
                                                setState(() {});
                                              },
                                            ),
                                          ),
                                        )
                                      ]
                                  )
                                ]),
                          )
                        // ],
                      ),
                      Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            playBtn(row: 0, column: 0),
                            playBtn(row: 0, column: 1),
                            playBtn(row: 0, column: 2),
                          ]),
                      Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            playBtn(row: 1, column: 0),
                            playBtn(row: 1, column: 1),
                            playBtn(row: 1, column: 2),
                          ]),
                      Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            playBtn(row: 2, column: 0),
                            playBtn(row: 2, column: 1),
                            playBtn(row: 2, column: 2),
                          ]),
                    ],
                  ),
                ),
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text(
                        helpText,
                        style: const TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    AbsorbPointer(
                        absorbing: startFight,
                        child:
                        Opacity(
                            opacity: startFight ? 0 : 1, child: beginBtn())),
                  ],
                ),
              ],
            ),
          );
        }
    );
  }

  //@override
  //Widget build (BuildContext context) {
  //}

  Widget playBtn({required int row, required int column}) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: AbsorbPointer(
        absorbing: game[row][column] == '' ? false : true,
        child: ElevatedButton(
          onPressed: () {
            setState(() {
              move(column: column, row: row);
            });
          },
          style: ElevatedButton.styleFrom(
              fixedSize: const Size(100, 100), backgroundColor: Colors.black38),
          child: Text(
            game[row][column],
            style: const TextStyle(fontSize: 50),
          ),
        ),
      ),
    );
  }

  Widget beginBtn() {
    loadScore();
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: ElevatedButton(
        onPressed: () {
          playSound();
          setState(() {
            startFight = true;
            moves = 0;
            game = List.generate(3, (i) => List.filled(3, ''));
            helpText = '$currentPlayer it is your move.';
          });
        },
        style: ElevatedButton.styleFrom(
            fixedSize: const Size(200, 50), backgroundColor: Theme.of(context).colorScheme.surface),
        child: Text(
          moves > 0 ? "Fight again" : "Go!",
          style: const TextStyle(fontSize: 20, color: Colors.black),
        ),
      ),
    );
  }

  //logica do click
  void move({required int row, required int column}) {
    moves++;
    game[row][column] = currentPlayer;
    bool winner = checkWinner(player: currentPlayer, row: row, column: column);
    String champion = "";

    if (winner) {
      helpText = '$currentPlayer Won!';
      if (currentPlayer == 'X') {
        xScore++;
        champion = "X";
      } else {
        oScore++;
        champion = "O";
      }
      startFight = false;
      _assetsAudioPlayer.stop();
      _dbService.update(xScore, oScore);
      _dbService.saveBattle(playerOne, playerTwo, champion);
      loadScore();
    } else if (winner == false && moves == 9) {
      helpText = 'Empate!';
      startFight = false;
      _assetsAudioPlayer.stop();
    } else {
      if (currentPlayer == 'X') {
        currentPlayer = 'O';
      } else {
        currentPlayer = 'X';
      }
      helpText = '$currentPlayer you move.';
    }
  }

  bool checkWinner(
      {required String player, required int row, required int column}) {
    bool venceu = true;
    //verfica linha
    for (int i = 0; i < 3; i++) {
      if (game[row][i] != player) {
        venceu = false;
        break;
      }
    }
    //verifica coluna
    if (venceu == false) {
      for (int j = 0; j < 3; j++) {
        if (game[j][column] != player) {
          venceu = false;
          break;
        } else {
          venceu = true;
        }
      }
    }

    //verifica diagonal
    if (venceu == false) {
      if (game[1][1] == player) {
        if (game[0][0] == player && game[2][2] == player) {
          venceu = true;
        } else if (game[0][2] == player && game[2][0] == player) {
          venceu = true;
        }
      }
    }
    return venceu;
  }

  Future<void> playSound() async {
    print('play');
    await _assetsAudioPlayer.open(
      Playlist(audios: audios, startIndex: 0),
      showNotification: true,
      autoStart: true,
    );
    _assetsAudioPlayer.play();
  }

  @override
  void dispose() {
    _assetsAudioPlayer.dispose();
    print('dispose');
    super.dispose();
  }

  loadScore() async {
    xScore = await _dbService.readX();
    oScore = await _dbService.readO();
  }

  Future<List<Player>> fetchPlayer() async {
    final client = ApiClient(Dio(BaseOptions(contentType: "application/json")));
    try {
      final response = await client.getPlayers();
      return response;
    } catch (e) {
      print(e);
      throw Exception("Falha ao carregar API");
    }
  }

  loadPlayers() async {
    playersApi = [];
    playersApi.clear();
    await fetchPlayer().then((value) {
      for (var player in value) {
        print(player.name);
        playersApi.add(player.name);
      }
    });

    print(playersApi);
  }
}

class Player {
  final int id;
  final String username;
  final String name;
  final String email;

  const Player({required this.name,
    required this.id,
    required this.username,
    required this.email});

  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
        name: json['name'],
        id: json['id'],
        username: json['username'],
        email: json['email']);
  }
}