import 'package:flutter_triple/flutter_triple.dart';

/*
class Counter extends StreamStore<Exception, String>{
}
*/