import 'dart:developer';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:trabalho_final_v2/my_game_page.dart';
import 'package:trabalho_final_v2/themes/my_theme.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();

  if(kIsWeb){
    log('web');
    print('web');
    await Firebase.initializeApp(options: const FirebaseOptions(
        apiKey: "AIzaSyBnrwmayL9oA1LVxzdKorKcwMSDR-lX8G8",
        authDomain: "fir-flutter-65768.firebaseapp.com",
        projectId: "fir-flutter-65768",
        storageBucket: "fir-flutter-65768.firebasestorage.app",
        messagingSenderId: "347672681738",
        appId: "1:347672681738:web:cf7c7b9270af631d27eef3"));
  }else{
    log('device');
    print('device');
    await Firebase.initializeApp();
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: myTheme,
      home: const MyGame(),
    );
  }
}
