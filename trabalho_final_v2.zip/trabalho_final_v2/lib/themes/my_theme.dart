import 'package:flutter/material.dart';

ThemeData myTheme = ThemeData(
  primaryColor: Colors.amber,

  colorScheme: ColorScheme.fromSwatch(
    primarySwatch: Colors.amber,
  ).copyWith(
    secondary: Colors.amber[200],
    tertiary: Colors.amberAccent,
    surface: Colors.white70,
  ),
);